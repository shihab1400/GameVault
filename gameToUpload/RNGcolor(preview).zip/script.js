let container1 = document.querySelector(".container1");
let container2 = document.querySelector(".container2");

let roundScore1 = document.querySelector(".round-score1");
let roundScore2 = document.querySelector(".round-score2");

let avgScore1 = document.querySelector(".avg-score1");
let avgScore2 = document.querySelector(".avg-score2");

let colorArr = [];

for (var i = 1; i <= 30; i++) {
   container1.innerHTML += `<div class="block"></div>`;
   container2.innerHTML += `<div class="block"></div>`;

   var rand1 = Math.floor(Math.random() * 256);
   var rand2 = Math.floor(Math.random() * 256);
   var rand3 = Math.floor(Math.random() * 256);

   colorArr.push(`rgb(${rand1}, ${rand2}, ${rand3})`);
}

let blocks1 = document.querySelectorAll(".container1 .block");
let blocks2 = document.querySelectorAll(".container2 .block");

var i = 0;
blocks1.forEach((block) => {
   block.style.background = colorArr[i++];
});

var j = 0;
blocks2.forEach((block) => {
   block.style.background = colorArr[j++];
});

let first, second, third;

let scoreArr1 = [];

var count1 = 0;
blocks1.forEach((block) => {
   block.addEventListener("click", () => {
      let hasSelectedClass = block.classList.contains("selected");
      if (!hasSelectedClass) {
         let rgb;
         let matches;
         let diff1, diff2, diff3, avg;
         rgb = block.style.background;
         matches = rgb.match(/\d+/g);
         if (count1 == 0) {
            first = parseInt(matches[0]);
            second = parseInt(matches[1]);
            third = parseInt(matches[2]);
         } else {
            var temp1 = parseInt(matches[0]);
            var temp2 = parseInt(matches[1]);
            var temp3 = parseInt(matches[2]);

            diff1 = 100 - (Math.abs(first - temp1) * 100) / 255;
            diff2 = 100 - (Math.abs(second - temp2) * 100) / 255;
            diff3 = 100 - (Math.abs(third - temp3) * 100) / 255;

            avg = (diff1 + diff2 + diff3) / 3;

            scoreArr1.push(avg);
            var sum = 0;
            for (var i = 0; i < scoreArr1.length; i++) {
               sum += scoreArr1[i];
            }

            var totalAvg = sum / scoreArr1.length;

            roundScore1.innerHTML = parseInt(avg) + "%";
            avgScore1.innerHTML = parseInt(totalAvg) + "%";
         }

         block.classList.add("selected");
         count1++;
         if (count1 == 2) {
            let selected = document.querySelectorAll(".selected");
            selected.forEach((s) => {
               s.style.display = "none";
            });
            count1 = 0;
         }
      }
   });
});

let scoreArr2 = [];
var count2 = 0;
blocks2.forEach((block) => {
   block.addEventListener("click", () => {
      let hasSelectedClass = block.classList.contains("selected");
      if (!hasSelectedClass) {
         let rgb;
         let matches;
         let diff1, diff2, diff3, avg;
         rgb = block.style.background;
         matches = rgb.match(/\d+/g);
         if (count2 == 0) {
            first = parseInt(matches[0]);
            second = parseInt(matches[1]);
            third = parseInt(matches[2]);
         } else {
            var temp1 = parseInt(matches[0]);
            var temp2 = parseInt(matches[1]);
            var temp3 = parseInt(matches[2]);

            diff1 = 100 - (Math.abs(first - temp1) * 100) / 255;
            diff2 = 100 - (Math.abs(second - temp2) * 100) / 255;
            diff3 = 100 - (Math.abs(third - temp3) * 100) / 255;

            avg = (diff1 + diff2 + diff3) / 3;

            scoreArr2.push(avg);
            var sum = 0;
            for (var i = 0; i < scoreArr2.length; i++) {
               sum += scoreArr2[i];
            }

            var totalAvg = sum / scoreArr2.length;

            roundScore2.innerHTML = parseInt(avg) + "%";
            avgScore2.innerHTML = parseInt(totalAvg) + "%";
         }

         block.classList.add("selected");
         count2++;
         if (count2 == 2) {
            let selected = document.querySelectorAll(".selected");
            selected.forEach((s) => {
               s.style.opacity = 0;
            });
            count2 = 0;
         }
      }
   });
});
